﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Main.Master" AutoEventWireup="true" CodeBehind="employeeReport.aspx.cs" Inherits="TemplatingPractice.pages.report.employee_info.employeeReport" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">

            <div class="content-page">
            
    <div class="content">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="page-title-box">
                        <ol class="breadcrumb p-0 m-0">
                            <li class="blue">Home</li>
                            <li class="blue">Reports</li>
                            <li class="blue">Employee </li>
                            <li class="active">Employee Information Report
                            </li>
                        </ol>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <!-- end row -->

            <div class="panel panel-color panel-info">
                <div class="panel-heading">
                    <h3 class="panel-title" style="color: red;">* Denotes Mandatory Fields</h3>
                </div>
                <div class="panel-body well">

                    <div method="post" action="./employeeReport" id="ctl00" role="form" class="form-horizontal">


                        <div id="content_upPnl">
	

                                <div class="form-group">
                                    <label class="control-label col-md-2">Branch <span style="color: red">*</span></label>
                                    <div class="col-md-4">
                                        <select name="ctl00$content$CmbBranch" onchange="javascript:setTimeout(&#39;WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$content$CmbBranch&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, true))&#39;, 0)" id="content_CmbBranch" title="Branch List" class="form-control" EnableVirtualScrolling="true" AutoValidate="true" AllowCustomText="true">
		<option selected="selected" value="Select Branch" disabled="disabled">Select Branch</option>
		<option value="4">Biratnagar</option>
		<option value="3">Dhangadi</option>
		<option value="1">Kupondole</option>

	</select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-md-2">Department <span style="color: red">*</span></label>
                                    <div class="col-md-4">
                                        <select name="ctl00$content$CmbDepartment" onchange="javascript:setTimeout(&#39;WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$content$CmbDepartment&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, true))&#39;, 0)" id="content_CmbDepartment" disabled="disabled" title="Department List" class="aspNetDisabled form-control" EnableLoadOnDemand="true" EnableVirtualScrolling="true" AutoValidate="true" SelectedIndexChanged="CmbDepartment_SelectedIndexChanged">
		<option selected="selected" value="Select Department">Select Department</option>
		<option value="1">Admin/Finance</option>
		<option value="3">Hardware</option>
		<option value="5">Software</option>
		<option value="7">Admin</option>

	</select>
                                    </div>
                                    <div class="col-sm-2">
                                        <input id="content_ChkDept" type="checkbox" name="ctl00$content$ChkDept" onclick="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$content$ChkDept\&#39;,\&#39;\&#39;)&#39;, 0)" /><span class="lbl"> All </span>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-md-2">Status <span style="color: red">*</span></label>
                                    <div class="col-md-4">
                                        <select name="ctl00$content$CmbStatus" onchange="javascript:setTimeout(&#39;WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$content$CmbStatus&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, true))&#39;, 0)" id="content_CmbStatus" title="Status List" class="form-control">
		<option selected="selected" value="Select Status" disabled="disabled">Select Status</option>
		<option value="0">Retired</option>
		<option value="1">Working</option>
		<option value="2">Suspension</option>
		<option value="3">Discharged</option>
		<option value="4">Dismissed</option>
		<option value="5">Resigned</option>
		<option value="6">Inactive</option>

	</select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-md-2">Type <span style="color: red">*</span></label>
                                    <div class="col-md-4">
                                        <select name="ctl00$content$CmbType" onchange="javascript:setTimeout(&#39;WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$content$CmbType&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, true))&#39;, 0)" id="content_CmbType" title="Type List" class="form-control">
		<option selected="selected" value="Select Type">Select Type</option>
		<option value="1">Permanent</option>
		<option value="2">Temporary</option>
		<option value="3">Contract</option>
		<option value="4">Casual</option>
		<option value="5">Trainee</option>
		<option value="6">Probation</option>
		<option value="7">Karar</option>
		<option value="8">Thekka Karar</option>
		<option value="9">Daily Waiges
</option>

	</select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-md-2">Sort <span style="color: red">*</span></label>
                                    <div class="col-md-4">
                                        <select name="ctl00$content$CmbSort" onchange="javascript:setTimeout(&#39;WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$content$CmbSort&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, true))&#39;, 0)" id="content_CmbSort" title="Sort List" class="form-control">
		<option selected="selected" value="1">Sort By Name</option>
		<option value="2">Sort By EMP ID</option>

	</select>
                                    </div>
                                </div>
                                <br />

                                <div class="col-md-12 col-md-offset-2">
                                    <div class="button-list">
                                        <input type="submit" name="ctl00$content$BtnLoad" value="Load" id="content_BtnLoad" class="btn btn-success col-md-2" />

                                        <input type="submit" name="ctl00$content$BtnReset" value="Cancel" id="content_BtnReset" class="btn btn-danger col-md-2" />
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="table-responsive">
                                            <div>

	</div>
                                        </div>
                                    </div>
                                </div>
                            
</div>
                    </div>
                </div>
            </div>
        </div>
        <!-- container -->
    </div>
    <!-- content -->

</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="cphScripts" runat="server">
</asp:Content>
